# from django.test import TestCase

# Create your tests here.
from django.test import TestCase
from rest_framework.test import APIClient
from rest_framework import status
from .models import Invoice, InvoiceDetail

class InvoiceAPITestCase(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.invoice_data = {
            "date": "2023-09-25",
            "customer_name": "Test Customer",
            "details": [
                {
                    "description": "Item 1",
                    "quantity": 2,
                    "unit_price": "10.50",
                    "price": "21.00"
                },
                {
                    "description": "Item 2",
                    "quantity": 3,
                    "unit_price": "7.25",
                    "price": "21.75"
                }
            ]
        }

    def test_create_invoice(self):
        response = self.client.post('/invoices/', self.invoice_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_get_invoices(self):
        response = self.client.get('/invoices/')
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_get_invoice_details(self):
        invoice = Invoice.objects.create(date="2023-09-25", customer_name="Test Customer")
        InvoiceDetail.objects.create(invoice=invoice, description="Item 1", quantity=2, unit_price="10.50", price="21.00")
        response = self.client.get(f'/invoices/{invoice.pk}/')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
